// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_MESSAGE
#define _H_NONNON_WIN32_WIN_MESSAGE




#include "../../neutral/posix.c"




#define n_win_message_send( h, m, w, l ) SendMessage( h, m, (WPARAM) (w), (LPARAM) (l) )
#define n_win_message_post( h, m, w, l ) PostMessage( h, m, (WPARAM) (w), (LPARAM) (l) )

BOOL
n_win_message_peek( MSG *msg )
{
	return PeekMessage( msg, NULL, 0, 0, PM_REMOVE );
}

MSG
n_win_message_remove( void )
{

	MSG msg;

	PeekMessage( &msg, NULL, 0, 0, PM_REMOVE );

	return msg;
}


#endif // _H_NONNON_WIN32_WIN_MESSAGE

