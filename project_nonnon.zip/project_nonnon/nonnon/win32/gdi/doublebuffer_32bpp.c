// Felis
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : DIBSection is used always
//
//	color will be different on 16bpp
//	so don't use this if background color is used




#ifndef _H_NONNON_WIN32_GDI_DOUBLEBUFFER_32BPP
#define _H_NONNON_WIN32_GDI_DOUBLEBUFFER_32BPP




#include "./doublebuffer.c"




static n_gdi_doublebuffer n_gdi_doublebuffer_32bpp_instance;

#define n_gdi_doublebuffer_32bpp_simple_init(         hgui, sx, sy ) n_gdi_doublebuffer_32bpp_init(         &n_gdi_doublebuffer_32bpp_instance, hgui, NULL, sx, sy )
#define n_gdi_doublebuffer_32bpp_simple_exit(                      ) n_gdi_doublebuffer_32bpp_exit(         &n_gdi_doublebuffer_32bpp_instance                     )
#define n_gdi_doublebuffer_32bpp_simple_exit_partial( x, y, sx, sy ) n_gdi_doublebuffer_32bpp_exit_partial( &n_gdi_doublebuffer_32bpp_instance,       x, y, sx, sy )
#define n_gdi_doublebuffer_32bpp_simple_visible(                   ) n_gdi_doublebuffer_32bpp_visible(      &n_gdi_doublebuffer_32bpp_instance                     )




HDC
n_gdi_doublebuffer_32bpp_init( n_gdi_doublebuffer *p, HWND hgui, HDC hdc, s32 sx, s32 sy )
{

	// [!] : use returned HDC to draw


	// [!] : race condition : prevent GDI handle leak

	if ( p->hdc != NULL ) { return p->hdc_compat; }


	// Init

	n_gdi_doublebuffer_zero( p );

	p->hgui           = hgui;
	p->hdc            = GetDC( p->hgui );
	p->hdc_compat     = CreateCompatibleDC( p->hdc );
	p->bpp            = GetDeviceCaps( p->hdc, BITSPIXEL );
	p->sx             = n_posix_max_s32( 1, abs( sx ) );
	p->sy             = n_posix_max_s32( 1, abs( sy ) );

	SelectObject( p->hdc_compat, n_win_font_get( hgui ) );


	int upsidedown = 1; if ( sy < 0 ) { upsidedown = -1; }


	n_gdi_dibsection_zero( &p->hbmp, &p->bmp );
	n_gdi_dibsection_init( &p->hbmp, &p->bmp, p->hgui, p->hdc_compat, p->sx, p->sy * upsidedown );


	p->hbmp_old = SelectObject( p->hdc_compat, p->hbmp );


	return p->hdc_compat;
}

void
n_gdi_doublebuffer_32bpp_cleanup( n_gdi_doublebuffer *p )
{

	SelectObject( p->hdc_compat, p->hbmp_old );


	n_gdi_dibsection_exit( &p->hbmp, &p->bmp );


	DeleteDC( p->hdc_compat );

	ReleaseDC( p->hgui, p->hdc );


	n_gdi_doublebuffer_zero( p );


	return;
}

#define n_gdi_doublebuffer_32bpp_exit( p ) n_gdi_doublebuffer_32bpp_exit_partial( p, 0,0,(p)->sx,(p)->sy )

void
n_gdi_doublebuffer_32bpp_exit_partial( n_gdi_doublebuffer *p, s32 x, s32 y, s32 sx, s32 sy )
{

	// Post Sync

	n_gdi_doublebuffer_sync_partial( p, x,y,sx,sy, n_posix_false );

	n_gdi_doublebuffer_32bpp_cleanup( p );


	return;
}

void
n_gdi_doublebuffer_32bpp_visible( n_gdi_doublebuffer *p )
{

	n_bmp_alpha_visible( &p->bmp );


	return;
}


#endif // _H_NONNON_WIN32_GDI_DOUBLEBUFFER_32BPP


