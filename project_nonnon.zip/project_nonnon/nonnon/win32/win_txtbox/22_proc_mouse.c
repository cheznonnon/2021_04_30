// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_proc_mouse( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->mouse_input_stop_onoff ) { return; }


	switch( msg ) {


	case WM_MOUSEWHEEL :

		if ( p->ime_composition_onoff ) { break; }


		// [!] : don't use n_win_txtbox_is_hovered() : scrollbars will be excluded

		if ( p->is_captured == n_posix_false )
		{
			if ( n_posix_false == n_win_is_hovered( p->hwnd ) ) { break; }
		}

		int delta = n_win_scrollbar_wheeldelta( wparam, 0, n_posix_true );

		n_win_txtbox_line_scroll( p, p->scroll_cch_tabbed_y + delta );

		n_win_scrollbar_scroll_pixel( &p->vscr, delta * p->vscr.pixel_step, N_WIN_SCROLLBAR_SCROLL_AUTO );

//n_win_txtbox_hwndprintf_literal( p, " %d : %d %g %g ", delta, p->scroll_cch_tabbed_y, p->vscr.unit_pos, p->vscr.pixel_pos );

		n_win_scrollbar_draw_always( &p->vscr, n_posix_true );
		n_win_txtbox_refresh( p );

	//break;
	case WM_MOUSEMOVE :

		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{

			if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL )
			{

				if ( n_posix_false == n_win_txtbox_is_hovered( p ) ) { break; }

				if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
				{
					if ( p->vscr.pressed_thumb ) { break; }
				}

				n_posix_bool ret = n_win_txtbox_line_select( p, p->hover_cch_y );
				n_win_txtbox_refresh( p );

				if ( ( ret == n_posix_false )&&( p->select_cch_sy ) )
				{
					n_win_txtbox_message_redirect( p, hwnd, msg );
				}

			}

		} else {

			n_win_txtbox_message_redirect( p, hwnd, msg );

		}

	break;


	case WM_LBUTTONDBLCLK :
	case WM_MBUTTONDBLCLK :
	case WM_RBUTTONDBLCLK :
	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :
	{

		if ( ( msg == WM_LBUTTONDBLCLK )||( msg == WM_LBUTTONDOWN ) ) { p->vk = VK_LBUTTON; } else
		if ( ( msg == WM_RBUTTONDBLCLK )||( msg == WM_RBUTTONDOWN ) ) { p->vk = VK_MBUTTON; } else
		if ( ( msg == WM_MBUTTONDBLCLK )||( msg == WM_MBUTTONDOWN ) ) { p->vk = VK_RBUTTON; }


		if ( ( msg == WM_RBUTTONDOWN )&&( n_win_is_input( VK_LBUTTON ) ) ) { break; }


		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ) { n_win_txtbox_message_redirect( p, hwnd, msg ); break; }


		if ( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_NO_DELAYEDFOCUS ) )
		{
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->focus_phase );

			if ( p->focus_phase_is_first )
			{
				p->focus_phase_is_first = n_posix_false;
				p->focus_phase          = N_WIN_TXTBOX_FOCUS_GO;
			}

			if ( p->focus_phase != N_WIN_TXTBOX_FOCUS_GO )
			{
				p->focus_phase = N_WIN_TXTBOX_FOCUS_GO;
				//if ( n_win_is_input( VK_MBUTTON ) ) { break; }
			}

		}


		static DWORD tripleclick_tmr  = 0;
		static UINT  tripleclick_pmsg = WM_NULL;
		static POINT tripleclick_pt   = { 0, 0 };


		if ( n_posix_false == n_win_txtbox_is_hovered( p ) ) { break; }
//n_win_hwndprintf_literal( hwnd, "%d %d", p->hover_cch_x, p->hover_cch_y );


		if ( p->is_static_ownerdraw ) { SetFocus( p->hwnd ); }


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			if ( p->ime_composition_onoff )
			{

				break;
/*
				n_win_txtbox_refresh_optimized_init( p );

				n_win_txtbox_unselect( p );
				n_win_txtbox_select( p, p->hover_cch_x, p->hover_cch_y, 0, 1 );

				n_win_txtbox_drag_select2drag( p );

				n_win_txtbox_refresh_optimized_exit( p, n_posix_false );


				HIMC himc = ImmGetContext( hwnd );

				n_win_txtbox_draw( p );

				COMPOSITIONFORM cf = { CFS_FORCE_POSITION | CFS_POINT, p->ime, { 0,0,0,0 } };
				ImmSetCompositionWindow( himc, &cf );

				ImmReleaseContext( hwnd, himc );
*/
			} else
			if ( msg == WM_RBUTTONDOWN )
			{
/*
				n_win_txtbox_refresh_optimized_init( p );

				n_win_txtbox_unselect( p );
				n_win_txtbox_select( p, p->hover_cch_x, p->hover_cch_y, 0, 1 );

				n_win_txtbox_drag_select2drag( p );

				n_win_txtbox_refresh_optimized_exit( p, n_posix_true );
*/
			} else
			if ( msg == WM_LBUTTONDBLCLK )
			{

				if ( p->is_hovered_linenum )
				{

					n_win_txtbox_refresh_optimized_init( p );

					if ( n_string_is_empty( n_txt_get( &p->txt, p->hover_cch_y ) ) )
					{
						p->empty_line_selection = p->hover_cch_y;
					} else {
						n_win_txtbox_line_select( p, p->hover_cch_y );
						n_win_txtbox_drag_select2drag( p );
					}

					n_win_txtbox_refresh_optimized_exit( p, n_posix_false );

					break;
				}


				// Triple-Click : Start

				if ( ( GetTickCount() - tripleclick_tmr ) > GetDoubleClickTime() )
				{
					tripleclick_tmr = 0;
				} else {
					tripleclick_tmr = GetTickCount();
				}


				// [!] : for usability

				tripleclick_pmsg = WM_LBUTTONDBLCLK;

				GetCursorPos( &tripleclick_pt );


				if ( n_string_is_empty( n_txt_get( &p->txt, p->hover_cch_y ) ) )
				{

					n_win_txtbox_refresh_optimized_init( p );

					p->empty_line_selection = p->hover_cch_y;

					n_win_txtbox_refresh_optimized_exit( p, n_posix_false );

				} else {

					n_win_txtbox_refresh_optimized_init( p );

					s32 f,t;
					n_win_txtbox_select_word( p, p->hover_cch_x, p->hover_cch_y, &f, &t );
					n_win_txtbox_select( p, f, p->hover_cch_y, t - f, 1 );
					n_win_txtbox_drag_select2drag( p );

					n_win_txtbox_refresh_optimized_exit( p, n_posix_false );

				}

			} else
			if ( msg == WM_LBUTTONDOWN )
			{
//n_win_txtbox_debug_count( p );

				n_posix_bool tripleclick_onoff = n_posix_true;


				// Triple-Click : End

				if ( ( GetTickCount() - tripleclick_tmr ) > GetDoubleClickTime() )
				{
					tripleclick_tmr = GetTickCount();
					tripleclick_onoff = n_posix_false;
				} else {
					tripleclick_tmr = 0;
				}


				// [!] : for usability

				if ( tripleclick_pmsg != WM_LBUTTONDBLCLK )
				{
					tripleclick_onoff = n_posix_false;
				} else {
					tripleclick_pmsg = WM_LBUTTONDOWN;
				}


				{

					int threshold_sx = 0;
					int threshold_sy = 0;
					n_win_mouse_threshold( hwnd, &threshold_sx, &threshold_sy );

					POINT p;
					GetCursorPos( &p );

					if (
						( threshold_sx < abs( p.x - tripleclick_pt.x ) )
						||
						( threshold_sy < abs( p.y - tripleclick_pt.y ) )
					)
					{
						tripleclick_onoff = n_posix_false;
					}

				}

				if ( tripleclick_onoff )
				{

					if ( n_string_is_empty( n_txt_get( &p->txt, p->hover_cch_y ) ) )
					{

						n_win_txtbox_refresh_optimized_init( p );

						p->empty_line_selection = p->hover_cch_y;

						n_win_txtbox_refresh_optimized_exit( p, n_posix_false );

					} else {

						n_win_txtbox_refresh_optimized_init( p );

						n_win_txtbox_line_select( p, p->hover_cch_y );
						n_win_txtbox_drag_select2drag( p );

						n_win_txtbox_refresh_optimized_exit( p, n_posix_false );

					}

				} else {
//n_win_txtbox_hwndprintf_literal( p, " Single Click " );

					p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;

					p->is_dragging = n_posix_false;


					n_win_txtbox_refresh_optimized_init( p );

					n_win_txtbox_message_redirect( p, hwnd, msg );

					if ( n_win_is_input( VK_SHIFT ) )
					{

						n_win_txtbox_drag( p );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " Dragging Start : %d : %d ", p->shift_dragging, p->prv_drag );

						n_win_txtbox_unselect( p );
						n_win_txtbox_select( p, p->hover_cch_x, p->hover_cch_y, 0, 1 );

						n_win_txtbox_drag_select2drag( p );


						s32  y = p->select_cch_y;
						s32 tx = 0; n_win_txtbox_tabbedmetrics( p, y, -1,p->select_cch_x,-1, NULL,NULL,&tx );

						if ( tx < ( p->scroll_pxl_tabbed_x / p->font_pxl_sx ) )
						{
							n_win_txtbox_scroll( p, p->select_cch_x * p->font_pxl_sx, p->scroll_cch_tabbed_y );
						}

//n_win_txtbox_hwndprintf_literal( p, "%d %d", p->drag_cch_x, p->drag_cch_y );

					}

					n_win_txtbox_refresh_optimized_exit( p, n_posix_true );


					p->hscr.stop_onoff = n_posix_true;
					p->vscr.stop_onoff = n_posix_true;

					p->is_captured = n_posix_true;
					SetCapture( hwnd );

					p->drag_onoff = n_posix_true;
					n_win_timer_init( hwnd, p->drag_timer, p->drag_msec );

				}

			} else { break; }

		} else {
//n_win_txtbox_debug_count( p );

			n_posix_bool ret = n_win_txtbox_line_select( p, p->hover_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " %d ", ret );


			if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL )
			{
				if ( p->hover_cch_y >= p->txt.sy ) { break; }
			}


			n_win_txtbox_refresh( p );

			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
			{
				n_win_scrollbar_refresh( &p->hscr );
			}

			if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
			{
				n_win_scrollbar_refresh( &p->vscr );
			}


			if ( ( ret == n_posix_false )&&( p->select_cch_sy ) )
			{
//n_posix_debug_literal( " %d %d %d ", p->hover_cch_y, p->select_cch_y, p->select_cch_sy );
				n_win_txtbox_message_redirect( p, hwnd, msg );
			}

		}

	}
	break;

	case WM_TIMER :
	{

		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ) { break; }


		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != p->drag_timer ) { break; }


		// [!] : don't break for mouse capture

		n_posix_bool is_hovered = n_win_txtbox_is_hovered( p );
//n_win_txtbox_hwndprintf_literal( p, " %d ", is_hovered );

		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			if ( p->is_captured == n_posix_false ) { break; }


			// [!] : prevent drawing when keep on pressing

			static s32 p_scroll_y = N_WIN_TXTBOX_NOT_SELECTED;

			if ( p_scroll_y == p->scroll_cch_tabbed_y )
			{

				static s32 p_cursor_x = -1;
				static s32 p_cursor_y = -1;

				s32 cursor_x, cursor_y; n_win_cursor_position_relative( p->hwnd, &cursor_x, &cursor_y );
				if ( ( p_cursor_x == cursor_x )&&( p_cursor_y == cursor_y ) )
				{
					if ( is_hovered ) { break; }
				}

				p_cursor_x = cursor_x;
				p_cursor_y = cursor_y;

			}

			p_scroll_y = p->scroll_cch_tabbed_y;


//n_win_txtbox_debug_count( p );

			p->is_dragging = n_posix_true;

			n_win_txtbox_refresh_optimized_init( p );

			n_win_txtbox_drag( p );
//is_hovered = n_posix_false;
			if ( is_hovered )
			{
				n_win_txtbox_refresh_optimized_exit( p, n_posix_false );
			} else {
				n_win_txtbox_refresh( p );
			}
//n_win_hwndprintf_literal( hwnd, " %d %d : %d %d ", p->hover_cch_x, p->hover_cch_y, p->drag_cch_x, p->drag_cch_y );

		}

	}
	break;

	case WM_LBUTTONUP :
	case WM_MBUTTONUP :
	case WM_RBUTTONUP :
	{

		if ( ( msg == WM_RBUTTONUP )&&( n_win_is_input( VK_LBUTTON ) ) ) { break; }


		p->vk = 0;


		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ) { n_win_txtbox_message_redirect( p, hwnd, msg ); break; }


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			if ( msg == WM_RBUTTONUP )
			{
//n_win_txtbox_debug_count( p );

				if ( p->ime_composition_onoff ) { break; }


				// [Needed] : for multiple instances

				if ( n_win_txtbox_is_hovered( p ) )
				{

					if ( n_win_menu_stop_onoff ) { break; }


					p->menu_onoff = n_posix_true;
					n_win_message_send( GetParent( p->hwnd ), WM_SETCURSOR, p->hwnd, 0 );

					if ( p->is_hovered_linenum )
					{
						p->menu_type = N_WIN_TXTBOX_MENU_LINE;

						n_win_simplemenu_show( &p->menu_linenum, hwnd );
					} else {
						p->menu_type = N_WIN_TXTBOX_MENU_MAIN;

						n_win_simplemenu_show( &p->menu_editbox, hwnd );
					}

				}

			} else
			if ( msg == WM_MBUTTONUP )
			{

				if ( p->is_hovered_linenum )
				{
					n_win_txtbox_autofocus( p );
					n_win_txtbox_refresh( p );
				}

			} else
			if ( msg == WM_LBUTTONUP )
			{

				// [!] : don't do n_win_txtbox_is_hovered()
				//
				//	capture will not be released when a cursor goes outside of a window

				if ( p->is_captured )
				{

					if ( p->drag_onoff )
					{
						p->drag_onoff = n_posix_false;
						n_win_timer_exit( hwnd, p->drag_timer );
					}

					ReleaseCapture();

					p->hscr.stop_onoff = n_posix_false;
					p->vscr.stop_onoff = n_posix_false;

					p->is_captured = n_posix_false;
					p->is_dragging = n_posix_false;

				}

			}

		}


		n_win_txtbox_message_redirect( p, hwnd, msg );

	}
	break;


	} // switch


	if ( p->menu_type == N_WIN_TXTBOX_MENU_MAIN )
	{
		n_win_txtbox_proc_menu_editbox( hwnd, msg, wparam, lparam, p );
	}

	if ( p->menu_type == N_WIN_TXTBOX_MENU_LINE )
	{
		n_win_txtbox_proc_menu_linenum( hwnd, msg, wparam, lparam, p );
	}


	return;
}


