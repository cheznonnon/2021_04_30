// test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include <windows.h>




HWND n_exec_hwnd;




// internal : callback for EnumWindows()
BOOL CALLBACK
n_exec_pid2hwnd( HWND hwnd, LPARAM lparam )
{

	DWORD pid;


	GetWindowThreadProcessId( hwnd, &pid );
	if ( pid == lparam )
	{
		if ( NULL == GetParent( hwnd ) )
		{

			n_exec_hwnd = hwnd;

			return FALSE;
		}
	}


	return TRUE;
}

void
n_exec( char *command, WORD showwindow, BOOL dos )
{

	// PROCESS_INFORMATION is needed to execute

	STARTUPINFO         si;
	PROCESS_INFORMATION pi;


	ZeroMemory( &si, sizeof(STARTUPINFO) );
	si.cb = sizeof(STARTUPINFO);


	// Win9x : command prompt will halt when use SW_HIDE or SW_MINIMIZE

	if ( dos )
	{
		if ( showwindow == SW_HIDE )
		{
			showwindow = SW_MINIMIZE;
		}
	}

	si.wShowWindow = showwindow;
	si.dwFlags     = STARTF_USESHOWWINDOW;

/*
	// Win9x : this trick is not available

	si.dwX      = -100;
	si.dwY      = -100;
	si.dwXSize  = 0;
	si.dwYSize  = 0;
	si.dwFlags  = STARTF_USEPOSITION | STARTF_USESIZE;
*/
/*
	// no effect

	si.dwXCountChars = 0xffffffff;
	si.dwXCountChars = 0xffffffff;
	si.dwFlags       |= STARTF_USECOUNTCHARS;
*/
	//si.hStdOutput = (HANDLE) STD_OUTPUT_HANDLE;
	//si.dwFlags    = STARTF_USESTDHANDLES;


	ZeroMemory( &pi, sizeof(PROCESS_INFORMATION) );


	CreateProcess
	(
		NULL,
		command,
		NULL,NULL,
		FALSE,
		NORMAL_PRIORITY_CLASS,
		NULL,
		NULL,
		&si, &pi
	);


	//WaitForSingleObject( pi.hThread, INFINITE );


	// Win9x : this trick is not available

	if ( dos )
	{
		Sleep( 1000 );

		EnumWindows( n_exec_pid2hwnd, (LPARAM) pi.dwProcessId );

		ShowWindow( n_exec_hwnd, SW_NORMAL );
	}


	CloseHandle( pi.hThread  );
	CloseHandle( pi.hProcess );


	return;
}

