// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : GCC3 : don't use optimization : a bug was found


// [x] : GCC4 : don't use -O and -mtune together
//
//	Windows Defender handles as a malware


// [!] : how to debug
//
//	for performance, search "Debug Center"
//
//	for item focus, search "focus setter", "focus remover"




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"




#include "../nonnon/com/IShellLink.c"


#include "../nonnon/win32/ole/IDropSource.c"
#include "../nonnon/win32/ole/IDropTarget.c"
#include "../nonnon/win32/ole/IPicture.c"
#include "../nonnon/win32/ole/IShellFolder.c"
#include "../nonnon/win32/ole/ITaskbarList.c"


#define N_GAME_WAKE
#define N_GAME_NO_WINMAIN
#include "../nonnon/game/game.c"


#include "../nonnon/game/click.c"
#include "../nonnon/game/progressbar.c"
#include "../nonnon/game/transition.c"


#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/neutral/dir.c"
#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/ini.c"
#include "../nonnon/neutral/png.c"
#include "../nonnon/neutral/string_path.c"
#include "../nonnon/neutral/time.c"


#include "../nonnon/neutral/jpg.c"


#include "../nonnon/win32/clipboard.c"
#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/gdi.c"
#include "../nonnon/win32/gdi/doublebuffer_32bpp.c"
#include "../nonnon/win32/registry.c"
#include "../nonnon/win32/sysinfo.c"
#include "../nonnon/win32/uxtheme.c"
#include "../nonnon/win32/win_filer.c"
#include "../nonnon/win32/win_scrollbar.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/win_txtbox.c"


#include "../nonnon/project/macro.c"




// [!] : Component : base

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_ORANGECAT ( 0 )
#define N_APPS_OPTION_ORANGECAT      N_STRING_EMPTY

#endif // #ifndef NONNON_APPS


#include "./oc_rect.c"


// [!] : Component : order is important

#include "./oc_extern.c"

#include "./oc_color.c"
#include "./oc_font.c"

#include "./oc_event.c"

#include "./oc_ini.c"

#include "./oc_core.c"

#include "./oc_key_operation.c"

#include "./oc_find.c"

#include "./oc_item.c"
#include "./oc_item_autoscroll.c"
#include "./oc_item_drag2select.c"
#include "./oc_item_hover2tooltip.c"
#include "./oc_item_multifocus.c"
#include "./oc_item_preload_thread.c"
#include "./oc_item_progressbar.c"
#include "./oc_item_scroll.c"
#include "./oc_item_sync.c"
#include "./oc_item_sync_thread.c"

#include "./oc_info.c"
#include "./oc_path.c"

#include "./oc_menu.c"

#include "./oc_subclass.c"

#include "./oc_IDropTarget.c"




// internal
void
n_oc_on_viewchange( int item_index, int path_index, n_bool is_text )
{

	n_oc_event_zero();


	// [x] : multi-thread : this causes less responsive : see oc_item_sync_thread.c
	//if ( n_false == n_game_refresh_is_off() ) { return; }


	if ( game.hwnd != GetActiveWindow() ) { return; }


	// [Patch] : for "-find" option

	static n_bool is_first = n_true;


	if ( oc.view == N_ORANGECAT_VIEW_FILE )
	{

		if ( item.drag != N_ORANGECAT_DRAG_NEUTRAL ) { return; }


		n_win_simplemenu_hide( &oc.menu );


		if ( ( item_index == N_ORANGECAT_NOTHING )&&( path_index == N_ORANGECAT_NOTHING ) )
		{

			if ( oc.view_is_computer ) { return; }


			if ( is_text )
			{
				oc.find_mode = N_ORANGECAT_FIND_MODE_TEXT;
			} else {
				oc.find_mode = N_ORANGECAT_FIND_MODE_NAME;
			}

			n_string_path_free( oc.info ); oc.info = NULL;

		} else {
//n_game_hwndprintf_literal( " %d ", path_index );

			oc.find_mode = N_ORANGECAT_FIND_MODE_NONE;

			if ( item_index != N_ORANGECAT_NOTHING )
			{

				n_string_path_free( oc.info );
				oc.info = n_oc_item_index2path_new( &item, item_index );

			} else {

				n_string_path_free( oc.info );
				oc.info = n_oc_path_index2path_new( &path, path_index );

				if ( n_string_is_same( N_ORANGECAT_COMPUTER, oc.info ) )
				{
					n_string_truncate( oc.info );
				}

			}

			if ( is_text )
			{
				n_IShellFolder_popupmenu( game.hwnd, oc.info );
				//n_explorer_property( oc.info );
				return;
			}

		}


		is_first = n_false;


		oc.view_prev = oc.view;
		oc.view      = N_ORANGECAT_VIEW_INFO;

		n_oc_event_init();

	} else
	if ( oc.view == N_ORANGECAT_VIEW_INFO )
	{
/*
n_oc_info_exit( &info );
oc.view_prev = oc.view;
oc.view      = N_ORANGECAT_VIEW_FILE;
item.is_blank = n_false;
n_oc_event_redraw();
return;
*/

		n_oc_event_zero();
		n_bool ret = n_oc_info_go( &info ); n_oc_info_exit( &info );

//n_posix_debug_literal(  " %s ", oc.find );
//n_posix_debug_literal( "%d : %s", ret, oc.info );
//n_oc_event_init();

		oc.view_prev = oc.view;
		oc.view      = N_ORANGECAT_VIEW_FILE;

		if ( is_first )
		{
//n_posix_debug_literal(  " %s %d ", oc.find, item.view_type );

			is_first = n_false;

			n_oc_event_init();


			if ( n_string_is_empty( oc.find ) ) { oc.find_mode = N_ORANGECAT_FIND_MODE_NONE; }

		} else
		if ( ret )
		{

			if ( oc.find_mode )
			{
//n_game_hwndprintf_literal( "n_oc_event_init()" );

				// Find

				n_oc_event_init();

			} else {
//n_game_hwndprintf_literal( "n_oc_event_redraw() : ret is n_true" );

				// Rename

				n_oc_event_redraw();

			}


			// [Needed] : Maximized <=> Restored

			n_oc_path_init( &path );
			n_oc_item_on_resize( &item );

			if ( item.count == 0 ) { item.is_blank = n_false; }

		} else {
//n_game_hwndprintf_literal( "n_oc_event_redraw() : ret is n_false" );

			// [Needed] : Maximized <=> Restored

			n_oc_path_init( &path );
			n_oc_item_on_resize( &item );

			n_oc_item_patch_focus_on( &item, n_true );


			if ( item.count == 0 ) { item.is_blank = n_false; }


			n_oc_event_redraw();

		}

	}


	return;
}

void
n_oc_on_click( void )
{

	// [!] : oc.is_*button will be n_true when border is double-clicked
	//
	//	see WM_NCLBUTTONDBLCLK and WM_TIMER @ oc_subclass.c

	if ( oc.input_onoff )
	{
		oc.is_lbutton = n_win_is_input( VK_LBUTTON );
		oc.is_mbutton = n_win_is_input( VK_MBUTTON );
		oc.is_rbutton = n_win_is_input( VK_RBUTTON );
//n_game_hwndprintf_literal( " %d %d %d ", oc.is_lbutton, oc.is_mbutton, oc.is_rbutton );
	}

	oc.is_input = ( oc.is_lbutton | oc.is_mbutton | oc.is_rbutton );


	return;
}

void
n_oc_on_keyinput( void )
{

	// [!] : Global Key/Mouse Binding

	if (
		( game.is_active )
		&&
		( item.drag == N_ORANGECAT_DRAG_NEUTRAL )
		&&
		( oc.is_external_dnd == n_false )
		&&
		( n_IDropTarget_is_running == n_false )
	)
	{

		// [!] : View Switcher
//n_game_hwndprintf_literal( "%d", oc.view_hover );

		if ( ( n_game_click_single( &oc.singleclick_r ) )&&( oc.is_inner ) )
		{

			n_posix_sleep( N_ORANGECAT_INTERVAL_BASE / 2 );

			// [Patch] : non-client area needs to be excluded

			if (
				( ( oc.cursor_x >= 0 )&&( oc.cursor_x <= game.sx ) )
				&&
				( ( oc.cursor_y >= 0 )&&( oc.cursor_y <= game.sy ) )
			)
			{

				if ( oc.view == N_ORANGECAT_VIEW_FILE )
				{
					n_oc_event_viewchange();
				} else
				if ( oc.view == N_ORANGECAT_VIEW_INFO )
				{
					if ( n_false == n_oc_info_input_is_hovered( &info ) )
					{
						n_oc_event_viewchange();
					}
				}

				return;
			}

		}


		if ( oc.view == N_ORANGECAT_VIEW_FILE )
		{

			// [!] : Item Deleter

			if ( n_game_click_single( &oc.singleclick_delete ) )
			{

				if ( n_oc_item_multifocus_is_on( &item ) )
				{

					n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );

					if ( n_win_is_input( VK_CONTROL ) )
					{

						n_oc_item_multifocus_delete( &item );

					} else {

						n_posix_char *str = n_oc_item_multifocus_focus2path_new( &item );

						n_bool ret = n_explorer_recyclebin( game.hwnd, str );

						n_string_path_free( str );

						if ( ret ) { n_project_dialog_info( game.hwnd, n_project_string_error ); }

					}

					n_oc_item_sync_on_delete( &item );

					item.drag = N_ORANGECAT_DRAG_NEUTRAL;

				}

			}


			// Key Binding

			if ( n_game_click_single( &oc.singleclick_bspace ) )
			{
				n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );
				n_oc_navigate_back();
			}

			if ( n_win_is_input( VK_CONTROL ) )
			{

				if ( n_win_is_input( 'A' ) )
				{
					n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );

					n_oc_item_multifocus_on_all( &item );
					n_oc_event_redraw_fast();
				} else
				if ( n_win_is_input( 'F' ) )
				{
					n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );

					n_oc_on_viewchange( N_ORANGECAT_NOTHING, N_ORANGECAT_NOTHING, n_false );
				} else
				if ( n_win_is_input( 'G' ) )
				{
					n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );

					n_oc_on_viewchange( N_ORANGECAT_NOTHING, N_ORANGECAT_NOTHING, n_true );
				} else
				if ( n_win_is_input( VK_F1 ) )
				{
					n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );

					oc.debug_icon = n_oc_bool_toggle( oc.debug_icon );

					n_oc_item_view_change( &item );
					n_oc_event_redraw();
				}

			}
/*
			if ( n_win_is_input( VK_F1 ) )
			{
				n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );

				n_bmp_flush( &game.bmp, n_bmp_white );
				item.is_blank = n_true;

				n_game_refresh_on();
			}
*/
/*
			if ( n_win_is_input( VK_F1 ) )
			{
				n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );

				int index = n_oc_item_multifocus_single( &item );
				if ( index != N_ORANGECAT_NOTHING )
				{
					n_bmp_save_literal( &item.bmp[ index ], "ret.bmp" );
				}
			}
*/
		} // if ( oc.view == N_ORANGECAT_VIEW_FILE )

	}


	return;
}

void
n_oc_on_input( n_bool always_on )
{
//n_game_debug_count();

	if ( always_on == n_false )
	{
		if ( n_oc_event_is_busy() ) { return; }
	}
//n_game_debug_count();


	n_win_cursor_position_relative( game.hwnd, &oc.cursor_x, &oc.cursor_y );
//n_game_hwndprintf_literal( "%d %d", oc.cursor_x, oc.cursor_y );

	GetClientRect( game.hwnd, &oc.client );


	oc.view_hwnd = n_win_cursor2hwnd();
	oc.is_inner  = ( game.hwnd == oc.view_hwnd );
//n_game_hwndprintf_literal( " %d %d ", (int) oc.view_hwnd, oc.is_inner );


	static n_bool p_is_input = n_false;

	n_oc_on_click();


	if ( p_is_input != oc.is_input )
	{
//n_game_hwndprintf_literal( " %d %d ", p_is_input, oc.is_input );

		if ( ( oc.is_input )&&( oc.is_inner ) )
		{
			oc.is_internal_dnd = n_true;
		} else {
			oc.is_internal_dnd = n_false;
		}
//n_game_hwndprintf_literal( " %d ", oc.is_internal_dnd );


		if ( ( oc.is_input )&&( oc.is_inner == n_false ) )
		{
			oc.is_external_dnd = n_true;
		} else {
			oc.is_external_dnd = n_false;
		}


		oc.view_is_desktop = n_oc_is_desktop() | n_oc_is_anotherwindow();
//n_game_hwndprintf_literal( " %d %d ", n_oc_is_desktop(), n_oc_is_anotherwindow() );

		if ( ( oc.is_input )&&( oc.is_inner ) )
		{
			oc.cursor_px = oc.cursor_x;
			oc.cursor_py = oc.cursor_y;
		}


		if ( oc.is_input == n_false )
		{
			oc.view_drag_oc2oc = n_false;
		}

	}

	if ( ( oc.is_input )&&( oc.is_inner ) )
	{
		oc.is_draggable = n_oc_is_draggable();
	} else {
		//oc.is_draggable = n_false;
	}

	p_is_input = oc.is_input;


	// [!] : oc.view_hover : hovered UI parts

	oc.view_hover = N_ORANGECAT_VIEW_HOVER_NONE;

	if ( oc.is_inner == n_false )
	{
		//
	} else
	if ( n_win_is_hovered_offset( game.hwnd, 0,0,game.sx,oc.unit_path ) )
	{
		oc.view_hover = N_ORANGECAT_VIEW_HOVER_PATH;
	} else
	if ( n_win_is_hovered_offset( game.hwnd, 0, oc.unit_path, item.sx, item.sy ) )
	{
		oc.view_hover = N_ORANGECAT_VIEW_HOVER_ITEM;
	} else
	if ( n_win_scrollbar_rect_is_hovered( &oc.scrollbar.rect_shaft, game.hwnd ) )
	{
		oc.view_hover = N_ORANGECAT_VIEW_HOVER_SCRL;
	}// else
//n_game_hwndprintf_literal( " %d ", oc.view_hover );


	// [!] : oc.view_drag_internal : currently pressing

	if ( oc.is_inner == n_false )
	{

		oc.view_drag_internal = N_ORANGECAT_DRAG_NEUTRAL;

	} else {

		if ( oc.is_input )
		{

			if ( oc.view_drag_internal == N_ORANGECAT_DRAG_NEUTRAL )
			{

				if ( oc.view_hover == N_ORANGECAT_VIEW_HOVER_PATH )
				{
					if ( oc.is_draggable ) { oc.view_drag_internal = N_ORANGECAT_DRAG_BREADCRUMB; }
				} else
				if ( oc.view_hover == N_ORANGECAT_VIEW_HOVER_ITEM )
				{
					if ( oc.is_draggable )
					{
						if ( oc.is_lbutton ) { oc.view_drag_internal = N_ORANGECAT_DRAG_LBUTTON; } else
						if ( oc.is_mbutton ) { oc.view_drag_internal = N_ORANGECAT_DRAG_MBUTTON; } else
						if ( oc.is_rbutton ) { oc.view_drag_internal = N_ORANGECAT_DRAG_RBUTTON; }
					}
				} else
				if ( oc.view_hover == N_ORANGECAT_VIEW_HOVER_SCRL )
				{
					if ( oc.is_draggable ) { oc.view_drag_internal = N_ORANGECAT_DRAG_SCROLL; }
				} else
				if ( oc.is_draggable )
				{
					oc.view_drag_internal = N_ORANGECAT_DRAG_UNKNOWN;
				}

			}

		} else {

			oc.view_drag_internal = N_ORANGECAT_DRAG_NEUTRAL;

		}

	}

//n_game_hwndprintf_literal( " %d ", oc.view_drag_internal );

	n_oc_on_keyinput();


	if ( oc.view == N_ORANGECAT_VIEW_FILE )
	{

		// [!] : DnD : OrangeCat to OrangeCat : source cursor

		static n_bool onoff = n_false;

		if ( oc.view_dnd_onoff == n_false )
		{
//n_game_debug_count();

			// [!] : for DnD from outside

			n_oc_item_on_click( &item );
			n_oc_path_on_click( &path );

			if ( game.is_active )
			{
				n_oc_item_scroll_on_keydown( &item );
			}

			if ( onoff )
			{
				onoff = n_false;
				n_win_cursor_add( NULL, IDC_ARROW );
			}

		} else {

			// [!] : see WM_SETCURSOR @ oc_subclass.c

			onoff = n_true;
			n_win_cursor_add( NULL, IDC_WAIT );

		}

	}


	// [Needed] : this position is important

	if ( ( oc.is_input )&&( oc.is_inner ) )
	{
		//oc.is_draggable = n_oc_is_draggable();
	} else {
		oc.is_draggable = n_false;
	}


	return;
}

#define n_oc_throbber_1( phase ) n_oc_throbber_main( phase, n_posix_literal( "<" ), n_posix_literal( ">" ) )
#define n_oc_throbber_2( phase ) n_oc_throbber_main( phase, n_posix_literal( "+" ), n_posix_literal( "+" ) )

void
n_oc_throbber_main( int phase, const n_posix_char *str_pre, const n_posix_char *str_pst )
{
if ( oc.debug_use_title ) { return; }

	n_posix_char pre[ 10 ]; n_string_truncate( pre );
	n_posix_char pst[ 10 ]; n_string_truncate( pst );

	n_bool pre_onoff = n_false;
	n_bool pst_onoff = n_true;

	if (
		( n_sysinfo_version_8_or_later() )
		&&
		( n_false == n_sysinfo_version_10_or_later() )
	)
	{
		pre_onoff = n_true;
	}


	if ( ( phase )&&( pst_onoff ) ) { n_posix_strcat( pst, n_posix_literal( " " ) ); }

	int i = 0;
	while( 1 )
	{
		if ( i >= phase ) { break; }

		if ( pre_onoff ) { n_posix_strcat( pre, str_pre ); }
		if ( pst_onoff ) { n_posix_strcat( pst, str_pst ); }

		i++;
	}

	if ( ( phase )&&( pre_onoff ) ) { n_posix_strcat( pre, n_posix_literal( " " ) ); }


	n_game_hwndprintf_literal( "%s%s%s", pre, N_ORANGECAT_APPNAME, pst );


	return;
}

void
n_oc_event_on_init( void )
{

	if ( oc.view == N_ORANGECAT_VIEW_FILE )
	{

		if ( oc.ITaskbarList3 == NULL ) { oc.ITaskbarList3 = n_ITaskbarList_init(); }


		oc.navigate_plzwait = n_true;
		//n_game_hwndprintf_literal( "%s", n_project_string_pleasewait );
		n_oc_throbber_1( 1 );

		if ( oc.debug_benchmark_onoff )
		{
			oc.debug_benchmark_timer = n_posix_tickcount();
		}

		n_oc_item_progressbar_reset( &item.progress_sync, N_ITASKBARLIST_MODE_GREEN );


		double scroll_restore = 0;

		if ( oc.view_navigate_onoff )
		{

			n_oc_navigate_history( oc.navi );

			n_string_path_free( oc.main );
			oc.main = n_string_path_carboncopy( oc.navi );
//n_posix_debug_literal( " %s ", oc.main );

			oc.view_is_computer = ( n_string_is_same( N_ORANGECAT_COMPUTER, oc.main ) );

			n_bool ret;
			if ( oc.view_is_computer )
			{
				ret = n_string_path_folder_change( oc.home );
			} else {
				ret = n_string_path_folder_change( oc.main );
			}
			if ( ret )
			{
//n_posix_debug_literal( " n_string_path_folder_change() " );
			}

			oc.find_mode  = N_ORANGECAT_FIND_MODE_NONE;
			oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;

			path.hover = N_ORANGECAT_NOTHING;

			if ( n_string_is_same( oc.back, oc.main ) ) { scroll_restore = oc.view_scroll_restore; }


			n_string_path_free( oc.link );
			oc.link = n_oc_item_multifocus_focus2path_new( &item );

		}

		oc.scrollbar_prv_pos = N_ORANGECAT_NOTHING;

//n_posix_debug_literal( " %s ", oc.find );
		n_bool ret = n_oc_item_init( &item );
		if ( ret )
		{
//n_posix_debug_literal( " n_oc_item_init() " );
		} else {
			n_oc_path_init( &path );

			if ( oc.view_navigate_onoff )
			{
				oc.view_scroll_restore = scroll_restore;
				n_oc_item_scroll_restore_back( &item );
			}
		}

		oc.view_navigate_onoff = n_false;

	} else
	if ( oc.view == N_ORANGECAT_VIEW_INFO )
	{

		n_oc_info_init( &info, oc.info );

	}


	// [Needed] : VC++ 2017

	oc.is_initialized = n_true;


	return;
}

void
n_oc_event_on_redraw( void )
{

	if ( oc.view == N_ORANGECAT_VIEW_FILE )
	{
//u32 dw = n_posix_tickcount();

		if ( oc.navigate_plzwait )
		{

			n_oc_throbber_1( 2 );

			//n_oc_item_preload( &item, N_ORANGECAT_INTERVAL_INIT, n_false );
			n_oc_item_preload_thread_go( N_ORANGECAT_INTERVAL_INIT );

			n_oc_throbber_1( 3 );

		}


		n_oc_item_erase( &item );
		n_oc_path_erase( &path );


		if ( ( oc.transition_onoff )&&( oc.transition_is_running ) )
		{

			if ( oc.view_hover == N_ORANGECAT_VIEW_HOVER_PATH )
			{

				n_oc_path_bitmap_make( &path );
				n_oc_path_on_click( &path );

				if ( path.hover != N_ORANGECAT_NOTHING )
				{
					n_oc_path_draw_single_aqua_forced_on_index = path.hover;

					n_bmp_fade_init( &path.fade[ path.hover ], oc_color.path_hover );
					path.fade[ path.hover ].stop = n_false;
				}

			} else
			if ( oc.view_hover == N_ORANGECAT_VIEW_HOVER_ITEM )
			{

				int  hover_index = N_ORANGECAT_NOTHING;
				n_bool hover_onoff = n_false;

				n_oc_item_collision( &item, &hover_index, &hover_onoff, n_true );

				if ( ( hover_onoff )&&( hover_index != N_ORANGECAT_NOTHING ) )
				{
					item.hover = hover_index;
					n_bmp_fade_init( &item.fade[ item.hover ], oc_color.item_hover );
					item.fade[ item.hover ].stop = n_false;
				}

			}

		}


		n_oc_item_draw( &item );
		n_oc_path_draw( &path );


		n_win_scrollbar_show( &oc.scrollbar, n_true );
		n_win_scrollbar_draw_always( &oc.scrollbar, n_true );


		// [Needed] : for busy loading
		n_oc_item_drag2select_draw( &item );


		if ( oc.debug_autoscroll_onoff )
		{
			oc.debug_autoscroll_onoff = n_false;

			s32 x = oc.debug_autoscroll_x - item.ox;
			s32 y = oc.debug_autoscroll_y - item.oy;

			n_bmp_box( &game.bmp, x,y, item.cell_sx,item.cell_sy, n_bmp_rgb( 0,200,255 ) );
		}


		n_oc_path_draw_single_aqua_forced_on_index = N_ORANGECAT_NOTHING;


		if ( oc.navigate_plzwait )
		{

			n_oc_throbber_1( 0 );

			oc.navigate_plzwait = n_false;

		}


		oc.titlemenu.onoff = n_true;


//n_game_hwndprintf_literal( "%d", (int) n_posix_tickcount() - dw );
	} else
	if ( oc.view == N_ORANGECAT_VIEW_INFO )
	{

		n_win_scrollbar_show( &oc.scrollbar, n_false );

		n_oc_info_draw( &info );


		oc.titlemenu.onoff = n_false;

	}


	n_game_refresh_on();


	return;
}

void
n_oc_filer_copy_callback( int copied, int count )
{

//int percent = (double) copied / count * 100;
//n_win_hwndprintf_literal( game.hwnd, "%d%%", percent );

	if ( copied == 0 )
	{
		n_oc_item_progressbar_reset( &item.progress_copy, N_ITASKBARLIST_MODE_YELLOW );
	} else
	if ( copied == count )
	{
		while( 1 )
		{
			n_oc_item_progressbar_main( &item.progress_copy, copied, count );
			n_win_message_send( game.hwnd, WM_PAINT, 0, 0 );

			n_ITaskbarList_stop( oc.ITaskbarList3, game.hwnd );

			if ( item.progress_copy.phase == N_ORANGECAT_PROGRESS_NONE ) { break; }
		}
	} else {
		n_oc_item_progressbar_main( &item.progress_copy, copied, count );
		n_win_message_send( game.hwnd, WM_PAINT, 0, 0 );

		n_ITaskbarList_loop( oc.ITaskbarList3, game.hwnd, copied, count );
	}


	return;
}

// nonnon game layer

n_bool
n_game_wake( void )
{

	n_posix_char *cmdline = n_win_commandline_new();

#ifdef NONNON_APPS

		// [Needed] : for Nonnon Apps

		n_string_commandline_option( N_APPS_OPTION_ORANGECAT, cmdline );

#endif // #ifdef NONNON_APPS


	n_bool ret = n_false;

	if ( n_string_path_commandline_option( N_ORANGECAT_OPTION_LABEL, cmdline, n_false ) )
	{

		// [!] : format : "C:\ NAME"
		//
		//	"C: Windows XP" is possible
		//	"C:\ "Windows XP"" is also possible

		int cch = n_posix_strlen( cmdline );

		n_posix_char *drive = n_string_path_new( cch );
		n_posix_char *label = n_string_path_new( cch );

		n_string_parameter_literal( cmdline, " ", "", 0, drive );
		n_string_parameter_literal( cmdline, " ", "", 1, label );


		n_posix_char *str = NULL;

		int n = n_posix_strlen( label );
		int x = 2;
		while( 1 )
		{

			n_string_path_free( str );
			str = n_string_path_new( cch );

			n_string_parameter_literal( cmdline, " ", "", x, str );

			if ( n_string_is_empty( str ) ) { break; }

			n += n_posix_sprintf_literal( &label[ n ], " %s", str );

			x++;

		}

		n_string_path_free( str );


		if ( n_string_path_is_drivename( drive ) )
		{

			n_string_terminate( drive, 2 );
			n_string_path_drivename_slash_add( drive );

			SetVolumeLabel( drive, label );

		}

//n_posix_debug_literal( "%s\n%s\n%d", drive, label, GetLastError() );


		n_string_path_free( drive );
		n_string_path_free( label );


		ret = n_true;

	}


	n_string_path_free( cmdline );


	return ret;
}

void
n_game_init( void )
{

	// System

	n_memory_debug_on();

	n_bmp_safemode = n_bmp_safemode_base = n_false;

	n_win_icon_init_replacer_check = n_false;
	n_win_icon_init_is_ui          = n_false;

	n_bmp_transparent_onoff_default = n_false;


	n_win_tabletpc_disable( game.hwnd );


	n_project_darkmode();


	n_game_title( N_ORANGECAT_APPNAME );

	game.sx       = (double) GetSystemMetrics( SM_CXMAXIMIZED ) * 0.4;
	game.sy       = (double) GetSystemMetrics( SM_CYMAXIMIZED ) * 0.4;
	//game.color    = n_bmp_white;
	game.fps      = 60;
	game.esc2exit = n_false;
	game.on_event = n_oc_on_event;
	game.on_close = n_oc_on_close;

	game.run_on_background = n_true;

#ifdef NONNON_APPS

	game.icon      = n_posix_literal( "ORANGECAT_0_MAIN" );

#endif // #ifdef NONNON_APPS

	{

		s32 csx,csy; n_win_desktop_size( &csx, &csy );
		if ( csx > csy )
		{
			game.sx = (double) game.sy * sqrt( 2 ) * 1.5;
		}

	}

	n_game_window_resizable();


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
	n_IDropTarget_init( game.hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET


	n_filer_copy_callback = n_oc_filer_copy_callback;


	// Init


	n_memory_zero( &oc, sizeof( n_oc_main ) );

	n_uxtheme_zero( &oc.uxtheme );

	n_oc_path_zero( &path );
	n_oc_item_zero( &item );
	n_oc_info_zero( &info );


	n_oc_IDropTarget_init();


	oc.msg_is_oc         = RegisterWindowMessage( N_ORANGECAT_MSG_IS_OC         );
	oc.msg_drag_internal = RegisterWindowMessage( N_ORANGECAT_MSG_DRAG_INTERNAL );
	oc.msg_drag_external = RegisterWindowMessage( N_ORANGECAT_MSG_DRAG_EXTERNAL );
	oc.msg_drag_oc2oc    = RegisterWindowMessage( N_ORANGECAT_MSG_DRAG_OC2OC    );
	oc.msg_path_sx       = RegisterWindowMessage( N_ORANGECAT_MSG_PATH_SX       );
	oc.msg_path_sy       = RegisterWindowMessage( N_ORANGECAT_MSG_PATH_SY       );
	oc.msg_is_computer   = RegisterWindowMessage( N_ORANGECAT_MSG_IS_COMPUTER   );
	oc.msg_hwnd          = RegisterWindowMessage( N_ORANGECAT_MSG_HWND          );
	oc.msg_is_droppable  = RegisterWindowMessage( N_ORANGECAT_MSG_IS_DROPPABLE  );
	oc.msg_find_onoff    = RegisterWindowMessage( N_ORANGECAT_MSG_FIND_ONOFF    );
	oc.msg_dnd_onoff     = RegisterWindowMessage( N_ORANGECAT_MSG_DND_ONOFF     );


	{
		oc.home = n_win_exepath_new();
		oc.exec = n_string_path_carboncopy( oc.home );
		n_string_path_upperfolder( oc.home, oc.home );
	}


	{
		int cch = n_posix_strlen( N_ORANGECAT_CPL_EXE );
		oc.cpnl = n_string_alloccopy( cch, N_ORANGECAT_CPL_EXE );
		ExpandEnvironmentStrings( N_ORANGECAT_CPL_EXE, oc.cpnl, cch );
	}


	n_posix_char *cmdline = n_win_commandline_new();

#ifdef NONNON_APPS

	// [Needed] : for Nonnon Apps

	n_string_commandline_option( N_APPS_OPTION_ORANGECAT, cmdline );

#endif // #ifdef NONNON_APPS


	n_bool no_upperfolder = n_false;


	oc.view      = N_ORANGECAT_VIEW_FILE;
	oc.find_mode = N_ORANGECAT_FIND_MODE_NONE;

	if ( n_string_path_commandline_option( N_ORANGECAT_OPTION_FIND_NAME, cmdline, n_false ) )
	{
//n_posix_debug_literal( " %s ", cmdline );
		oc.view      = N_ORANGECAT_VIEW_INFO;
		oc.find_mode = N_ORANGECAT_FIND_MODE_NAME;
		if ( n_posix_stat_is_dir( cmdline ) ) { no_upperfolder = n_true; }

		oc.view_find_startup = n_true;
	} else
	if ( n_string_path_commandline_option( N_ORANGECAT_OPTION_FIND_TEXT, cmdline, n_false ) )
	{
//n_posix_debug_literal( " %s ", cmdline );
		oc.view      = N_ORANGECAT_VIEW_INFO;
		oc.find_mode = N_ORANGECAT_FIND_MODE_TEXT;
		if ( n_posix_stat_is_dir( cmdline ) ) { no_upperfolder = n_true; }

		oc.view_find_startup = n_true;
	}


	n_bool folder_as_item = n_false;

	if ( n_string_path_commandline_option( N_ORANGECAT_OPTION_AS_ITEM, cmdline, n_false ) )
	{
		folder_as_item = n_true;
	}


	n_bool nolink = n_false;

	if ( n_string_path_commandline_option( N_ORANGECAT_OPTION_NOLINK, cmdline, n_false ) )
	{
		nolink = n_true;
	}


	if ( n_string_path_commandline_option( N_ORANGECAT_OPTION_SET, cmdline, n_true ) )
	{

		n_posix_char str[ 100 ];

		n_string_parameter( cmdline, N_STRING_COMMA, NULL, 0, str );
		game.x = n_posix_atoi( str );

		n_string_parameter( cmdline, N_STRING_COMMA, NULL, 1, str );
		game.y = n_posix_atoi( str );

		n_string_parameter( cmdline, N_STRING_COMMA, NULL, 2, str );
		s32 sx = n_posix_atoi( str );
		if ( sx != -1 ) { game.sx = sx; }

		n_string_parameter( cmdline, N_STRING_COMMA, NULL, 3, str );
		s32 sy = n_posix_atoi( str );
		if ( sy != -1 ) { game.sy = sy; }

		int i = 0;
		while( 1 )
		{

			if ( cmdline[ i ] == N_STRING_CHAR_NUL   )
			{
				n_posix_sprintf_literal( cmdline, "%s", &cmdline[ i ] );
				break;
			} else
			if ( cmdline[ i ] == N_STRING_CHAR_SPACE )
			{
				i++;
				n_posix_sprintf_literal( cmdline, "%s", &cmdline[ i ] );
				break;
			}

			i++;
		}
//n_posix_debug_literal( " %s ", cmdline );
	}


	n_posix_char *multipath = n_string_path_cmdline2multipath( cmdline );

	n_string_path_free( cmdline );

//n_posix_debug_literal( " 1 " );
	if ( 1 == n_string_path_multiple_count( multipath ) )
	{

		if ( nolink )
		{
			//
		} else
		if ( n_posix_stat_is_dir( multipath ) )
		{
			if ( folder_as_item == n_false ) { no_upperfolder = n_true; }
		} else
		if ( n_string_path_ext_is_same( N_ISHELLLINK_EXT, multipath ) )
		{

			n_posix_char *link = n_string_path_new( N_OC_LNK2PATH_CCH_MAX ); n_string_zero( link, N_OC_LNK2PATH_CCH_MAX );

			n_IShellLink_lnk2path( multipath, link, NULL, NULL, NULL );

			n_string_path_free( multipath );
			multipath = n_string_path_carboncopy( link );

			if ( n_posix_stat_is_dir( link ) ) { no_upperfolder = n_true; }

			n_string_path_free( link );

		}

	}


//n_posix_debug_literal( " 2 " );
	if ( n_string_is_same( N_ORANGECAT_COMPUTER, multipath ) )
	{

		oc.main = n_string_path_carboncopy( N_ORANGECAT_COMPUTER );

	} else {

		if ( n_string_is_empty( multipath ) )
		{

			oc.main = n_string_path_folder_current_new();

		} else {

			if ( no_upperfolder )
			{
				oc.main = n_string_path_carboncopy( multipath );
			} else {
				n_posix_char *dir = n_string_path_upperfolder_new( multipath );
//n_posix_debug_literal( " %d : %s ", cch, dir );
				oc.main = dir;
			}

		}
//n_posix_debug_literal( " %s ", oc.main );


		n_string_path_free( oc.head );
		oc.head = n_string_path_carboncopy_multiple( multipath );

		if ( n_false == n_string_is_empty( oc.head ) )
		{

			n_string_path_free( oc.main );

			if ( no_upperfolder )
			{
				oc.main = n_string_path_carboncopy( oc.head );
			} else {
				oc.main = n_string_path_upperfolder_new( oc.head );
			}

		}


		if ( n_string_path_folder_change( oc.main ) )
		{
			n_string_path_free( oc.main );
			oc.main = n_string_path_carboncopy( oc.home );

			n_string_path_folder_change( oc.main );
		}

	}

//n_posix_debug_literal( " 3 " );

//n_posix_debug_literal( " %s ", multipath );
	n_string_path_free( multipath );


	oc.view_is_computer = ( n_string_is_same( N_ORANGECAT_COMPUTER, oc.main ) );


	oc.input_onoff = n_true;


	// [!] : Scrollbar

	n_win_scrollbar_direct_render = n_true;

	n_win_scrollbar_init( &oc.scrollbar, game.hwnd, 0, 0 );

	oc.scrollbar.bmp_backbuffer = &game.bmp;

	n_win_scrollbar_parameter_add_page = n_false;

	oc.scrollbar.option |= N_WIN_SCROLLBAR_OPTION_PAGER;
	oc.scrollbar.option |= N_WIN_SCROLLBAR_OPTION_NO_ARROWS;
	oc.scrollbar.option |= N_WIN_SCROLLBAR_OPTION_DRAW_100PC;
	//oc.scrollbar.option |= N_WIN_SCROLLBAR_OPTION_USE_DI_HDC;
	oc.scrollbar.option |= N_WIN_SCROLLBAR_OPTION_RECALC_UNIT_MAX;
	oc.scrollbar.option |= N_WIN_SCROLLBAR_OPTION_NO_FASTMODE;

	oc.scrollbar.menu.callback = n_oc_item_scroll_callback;


	// [!] : after a scrollbar is made

	n_oc_menu_init();

	n_oc_reset();
	n_oc_event_init();


	// Debug Center

	oc.debug_benchmark_onoff   = n_false;//n_true;
	oc.debug_sync              = n_false;//n_true;
	oc.debug_use_title         = n_false;//n_true;
	oc.debug_drag2select_onoff = n_false;//n_true;

	if ( oc.debug_benchmark_onoff ) { oc.fade_onoff = oc.transition_onoff = n_false; }


	return;
}

void
n_game_loop( void )
{

	if ( oc.fade_onoff )
	{

		static n_bool is_first = n_true;

		if ( oc.view == N_ORANGECAT_VIEW_FILE )
		{
			if ( is_first )
			{
				is_first = n_false;
				n_oc_splashscreen();
			}
		}
		if ( oc.view == N_ORANGECAT_VIEW_INFO )
		{
			if ( is_first )
			{
				is_first = n_false;
				n_oc_info_flush( NULL, NULL, NULL );
			}
		}

	}


	// Event Extender

	// [!] : misbehave when maximized <=> restored

	if ( n_game_refresh_is_resize() )
	{
//n_game_debug_count();

		if ( oc.is_initialized )
		{
//n_game_debug_count();
			if ( oc.view == N_ORANGECAT_VIEW_FILE )
			{
//n_game_debug_count();
				n_oc_path_on_resize( &path );
				n_oc_item_on_resize( &item );

				item.is_blank = n_false;
				n_oc_event_on_redraw();

			} else
			if ( oc.view == N_ORANGECAT_VIEW_INFO )
			{

				n_oc_event_on_redraw();

			}

		}

	} else {

		// [!] : for too much faster environment like a virtual machine

		static n_bool is_first = n_true;

		if ( is_first )
		{
			static n_bool timer_init = n_false;
			static u32    timer      = 0;

			if ( timer_init == n_false )
			{
				timer_init = n_true;
				timer      = n_posix_tickcount();
			}

			if ( n_game_timer( &timer, N_ORANGECAT_INTERVAL_LOCK ) )
			{
				is_first = n_false;
			}
		} else {
			n_oc_on_input( n_false );
		}

	}


	// Main Events

//n_game_hwndprintf_literal( "Event %d", oc.event );


	switch( oc.event ) {


	case N_ORANGECAT_EVENT_INIT :

		n_oc_event_on_init();

		// [!] : cascading for speeding up

		//n_oc_event_zero();

	//break;

	case N_ORANGECAT_EVENT_REDRAW :
//n_game_debug_count();

		n_oc_event_on_redraw();

//n_game_hwndprintf_literal( "%s", oc.main );
//n_game_hwndprintf_literal( "%s", oc.back );
//n_game_hwndprintf_literal( "%s @ %d pt", n_oc_font_name, n_oc_font_size );
//n_game_hwndprintf_literal( "%d x %d", item.grid_sx, item.grid_sy );
//n_game_hwndprintf_literal( "Offset : %d x %d", item.ox, item.oy );

		n_oc_event_zero();

	break;


	case N_ORANGECAT_EVENT_TRANSITION :
	{

		if ( n_false == n_game_refresh_is_off() ) { break; }
//n_posix_debug_literal( " N_ORANGECAT_EVENT_TRANSITION : %d ", oc.transition_is_running );

		if ( oc.transition_onoff == n_false )
		{
			oc.event = oc.transition_event;

			break;
		}


		if ( oc.transition_is_running == n_false )
		{
//n_posix_debug_literal( "" );

			oc.transition_is_running = n_true;


			n_bmp_carboncopy( &game.bmp, &oc.transition_bmp_old );

			if ( oc.view_is_changed )
			{
				oc.view_is_changed = n_false;

				n_oc_item_view_change( &item );
			}


			if ( oc.transition_event == N_ORANGECAT_EVENT_INIT )
			{
				n_oc_event_on_init();
			}

			if ( oc.view != N_ORANGECAT_VIEW_INFO )
			{
				n_win_scrollbar_refresh_redraw_area( &oc.scrollbar );
				n_win_scrollbar_on_settingchange( &oc.scrollbar, n_false, n_true );
			}

			n_oc_event_on_redraw();

			if ( oc.view_prev == N_ORANGECAT_VIEW_INFO )
			{
				n_oc_item_hover2tooltip_collision( &item );
			}

			n_bmp_carboncopy( &game.bmp, &oc.transition_bmp_new );


			if ( oc.dwm_onoff )
			{
				// [!] : something is needed
			} else {
				n_bmp_alpha_visible( &oc.transition_bmp_old );
				n_bmp_alpha_visible( &oc.transition_bmp_new );
			}

//n_bmp_save_literal( &oc.transition_bmp_old, "old.bmp" );
//n_bmp_save_literal( &oc.transition_bmp_new, "new.bmp" );

		}
//oc.transition_type  = N_GAME_TRANSITION_SCROLL_U;


		if ( oc.dwm_onoff )
		{
			n_game_clear( game.color );
			n_bmp_flush_blendcopy( &oc.transition_bmp_old, &game.bmp, (double) n_game_transition_percent * 0.01 );
		}

		n_bool ret = n_game_transition
		(
			&game.bmp,
			&oc.transition_bmp_old,
			&oc.transition_bmp_new,
			N_ORANGECAT_INTERVAL_FADE,
			oc.transition_type
		);


		if ( oc.view_find_startup )
		{
			if ( ( n_game_transition_percent >=   0 )&&( oc.transition_throbber_phase == 0 ) )
	 		{
				oc.transition_throbber_phase = 1;
				n_oc_throbber_2( oc.transition_throbber_phase );
			} else
			if ( ( n_game_transition_percent >=  33 )&&( oc.transition_throbber_phase == 1 ) )
			{
				oc.transition_throbber_phase = 2;
				n_oc_throbber_2( oc.transition_throbber_phase );
			} else
			if ( ( n_game_transition_percent >=  66 )&&( oc.transition_throbber_phase == 2 ) )
			{
				oc.transition_throbber_phase = 3;
				n_oc_throbber_2( oc.transition_throbber_phase );
			} else
			if ( ( ret )&&( oc.transition_throbber_phase == 3 ) )
			{
				oc.transition_throbber_phase = 0;
				n_oc_throbber_2( oc.transition_throbber_phase );
			}
		}


		if ( ( ret )||( n_game_transition_percent == 0 ) )
		{

			oc.transition_is_running = n_false;

			oc.view_find_startup = n_false;;

			oc.event = N_ORANGECAT_EVENT_REDRAW;

			n_bmp_free( &oc.transition_bmp_old );
			n_bmp_free( &oc.transition_bmp_new );


			// [Needed] : when an item is not exist

			item.is_blank = n_false;


			if ( ( oc.dwm_onoff )&&( item.count == 0 ) )
			{
				n_oc_item_erase( &item );
			}

		} else {

			n_oc_event_transition();

		}
//n_game_hwndprintf_literal( " %d : %g ", ret, n_game_transition_percent );

		n_game_refresh_on();

	}
	break;


	case N_ORANGECAT_EVENT_VIEWCHANGE :

		n_win_scrollbar_on_input( & oc.scrollbar );
		if ( oc.scrollbar.hovered_thumb ) { n_oc_event_zero(); break; }
		if ( oc.scrollbar.hovered_shaft ) { n_oc_event_zero(); break; }

		n_oc_on_viewchange( item.hover, path.hover, n_win_is_input( VK_CONTROL ) );

	break;


	case N_ORANGECAT_EVENT_BTN_PRESS :

		if (
			( path.fade[ path.press ].color_bg = oc_color.path_press )
			||
			( path.fade[ path.press ].percent >= 100 )
		)
		{
			n_oc_path_go( &path );
		} else {
			n_oc_path_draw_single( &path, path.press );
		}

		n_game_refresh_on();

	break;


	case N_ORANGECAT_EVENT_ZERO :

//n_game_hwndprintf_literal( "Hover %d : Drag %d", item.hover, item.drag );
//n_game_hwndprintf_literal( "%d", game.is_active );
//n_game_hwndprintf_literal( "%d", oc.find_mode );
//n_game_hwndprintf_literal( "%d", oc.view_hover );
//n_game_hwndprintf_literal( " %d ", oc.view_is_key_operation );
//n_game_hwndprintf_literal( "%d %d", oc.is_draggable, item.drag );
//n_game_hwndprintf_literal( "%d", n_oc_path_hover_is_computer_global( &path ) );
//n_game_hwndprintf_literal( " View Focus %d ", oc.view_focus );
/*
n_game_hwndprintf_literal
(
	"oc.is_internal_dnd %d : oc.is_external_dnd %d : n_IDropTarget_is_running %d",
	 oc.is_internal_dnd,     oc.is_external_dnd,     n_IDropTarget_is_running    
);
*/
//n_game_hwndprintf_literal( " %f %f %f %f ", oc.scrollbar.pixel_pos, oc.scrollbar.pixel_step, oc.scrollbar.pixel_page, oc.scrollbar.pixel_max );
//n_game_hwndprintf_literal( " %f %f %f %f ", oc.scrollbar.unit_pos, oc.scrollbar.unit_step, oc.scrollbar.unit_page, oc.scrollbar.unit_max );
//n_game_hwndprintf_literal( " %f %f ", oc.scrollbar.pixel_thumb, oc.scrollbar.pixel_max );
//n_game_hwndprintf_literal( " %f %f ", oc.scrollbar.pixel_page, oc.scrollbar.pixel_thumb );
//n_game_hwndprintf_literal( " %g %g ", oc.scrollbar.pixel_thumb_original, oc.scrollbar.pixel_thumb );
//n_game_hwndprintf_literal( " %d ", oc.scrollbar.enabled );

//n_game_hwndprintf_literal( " %d ", oc.transition_is_running );

//n_game_hwndprintf_literal( " %d ", oc.view_drag_oc2oc );

//n_game_hwndprintf_literal( " %d ", oc.view_dnd_onoff );


		n_oc_item_sync_event( &item );

	break;


	} // switch()


	if ( oc.transition_is_running == n_false )
	{
		n_oc_item_hover2tooltip_main( &item );
	}


	// [Needed] : for fading

	if ( item.drag == N_ORANGECAT_DRAG_UNKNOWN )
	{

		if ( oc.is_internal_dnd )
		{
			if ( item.drag2select_onoff == n_false )
			{
				//n_oc_item_drag2select_init( &item );
			} else {
				n_oc_item_drag2select_loop( &item );
			}
		}

	}


	if ( oc.debug_benchmark_onoff == n_false )
	{
		if ( oc.view == N_ORANGECAT_VIEW_FILE )
		{
			n_oc_item_progressbar_main( &item.progress_sync, item.load_count, item.count );
		}
	}


	return;
}

void
n_game_exit( void )
{

	oc.exit_onoff = n_true;


	n_oc_path_exit( &path );
	n_oc_item_exit( &item );
	n_oc_info_exit( &info );


	n_string_path_free( oc.main );
	n_string_path_free( oc.head );
	n_string_path_free( oc.home );
	n_string_path_free( oc.exec );
	n_string_path_free( oc.back );
	n_string_path_free( oc.find );
	n_string_path_free( oc.info );
	n_string_path_free( oc.cpnl );
	n_string_path_free( oc.link );
	n_string_path_free( oc.navi );


	return;
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv, LPSTR cmd, int show )
{
	return n_game_main();
}

#endif // #ifndef NONNON_APPS

